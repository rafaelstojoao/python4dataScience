# Esse é um módulo que faz contas

def soma(a,b):
	return a+b

def subtrai(a,b):
	return a-b

def multiplica(a,b):
	return a*b

def divide(a,b):
	return a/b

def potencia(a,b):
	return a**b