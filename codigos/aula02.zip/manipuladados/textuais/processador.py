def tamanhoTexto(texto):
	return len(texto)
