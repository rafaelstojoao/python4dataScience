#from manipuladados import textuais
